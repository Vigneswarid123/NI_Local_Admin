export class AddDealermodel{
    constructor(
        // public dealername:string,
        // public dealeraddress1:string,
        // public dealeraddress2:string,
        // public dealeraddress3:string,
        // public dealercity:string,
        // public dealerstate:string,
        // public dealercountry:string,
        // public dealerzip: string,
        // public dealerphone: string,
        // public dealerlogo: string,
        // public dealerbrands:string,
        // public dealercreateduser = 1002,
        public dealername:string,
        public dealeraddress1:string,
        // public dealeraddress2:string,
        // public dealeraddress3:string,
        public dealercity:string,
        public dealerstate:string,
        public dealercountry:string,
        public dealerzip: string,
        public dealerphone: string,
        //public dealerlogo: string,
        public dealerbrands:string,
        public dealercreateduser = 1002,
        public dealergroupid =1002
        
    ){}
}