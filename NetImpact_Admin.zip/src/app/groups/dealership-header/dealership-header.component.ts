import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealership-header',
  templateUrl: './dealership-header.component.html',
  styleUrls: ['./dealership-header.component.scss']
})
export class DealershipHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
