import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealership-list',
  templateUrl: './dealership-list.component.html',
  styleUrls: ['./dealership-list.component.scss']
})
export class DealershipListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
