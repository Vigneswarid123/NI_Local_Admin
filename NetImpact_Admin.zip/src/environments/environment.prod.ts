export const environment = {
  production: true,
   apiUrl: 'http://throttleapi.azaz.com/api/'
   //apiUrl:'http://localapi.throttle.com/api/'
};
